%cleanvid
function cleanvid(vid)
    stop(vid)
    delete(vid)
    clear vid
end