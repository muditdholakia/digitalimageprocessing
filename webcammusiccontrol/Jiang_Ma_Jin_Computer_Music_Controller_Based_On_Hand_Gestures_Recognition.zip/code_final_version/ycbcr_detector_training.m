%ycbcr detector

function mask =ycbcr_detector(img_o, static_indicator)
    if static_indicator == true
        cw1_ycbcr = rgb2ycbcr(img_o);
    else
        cw1_ycbcr = img_o;
    end
    global convex_mask_training;
    [x y z] = size(cw1_ycbcr);
    mask=zeros(x,y);
    for i = 1:x
        for j=1:y
            if convex_mask_training(cw1_ycbcr(i,j,3),cw1_ycbcr(i,j,2))>0
                mask(i,j) = 255;
            end
        end
    end

    mask = bwareaopen(mask, 20, 8);
    mask = imerode(mask,strel('disk',6));
    mask = imdilate(mask,strel('disk',6));
end