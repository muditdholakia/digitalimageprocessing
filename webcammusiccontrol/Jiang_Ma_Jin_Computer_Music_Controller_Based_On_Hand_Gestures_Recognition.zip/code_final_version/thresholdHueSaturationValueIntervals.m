function imgMask = thresholdHueSaturationValueIntervals(imgHSV, hueThresh, satThresh, valThresh )
    [height, width, channels] = size(imgHSV);
    cond1 = imgHSV(:,:,1) > hueThresh(1);
    cond2 = imgHSV(:,:,1) <= hueThresh(2);
    cond3 = imgHSV(:,:,2) > satThresh(1);
    cond4 = imgHSV(:,:,2) <= satThresh(2);
    cond5 = imgHSV(:,:,3) > valThresh(1);
    cond6 = imgHSV(:,:,3) <= valThresh(2);
    imgMask = max(cond1,cond2);
    imgMask = min(imgMask, cond3);
    imgMask = min(imgMask, cond4);
    imgMask = min(imgMask, cond5);
    imgMask = min(imgMask, cond6);
end

